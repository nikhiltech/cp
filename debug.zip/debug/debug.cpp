#include <iostream>
#include <fstream>
#define MAXKEYLEN 20

using namespace std;

char *retrieve_key(char *stream1, char *stream2, int len, int keylen) {
	int j=0;
	char *s = new char [MAXKEYLEN];
	for(int i=0; i!=len; i++) {
		if(stream1[i]^stream2[i])
			s[++j] = stream1[i];
	}
	*keylen = j;
	return s;
}

void unlock_file(char *key, int keylen) {
	ifstream is("locked_file", ifstream::binary);
	is.seekg(0, is.end);
	int len = is.tellg();
	char *data = new char [len];
	is.read(data, len);
	is.close();
	int j=0;
	for(int i=0; i!=len; i++) {
		data[i] = data[i]^key[(j++)];
	}
	ofstream os("unlocked_file", ofstream::binary);
	os.write(data, len);
	os.close()
}

int main() {
	ifstream is("./image1.bmp", ifstream::binary);
	ifstream js("./image2.bmp", ifstream::binary);
	is.seekg(0, is.end);
	int l = is.tellg();
	char *data1 = new char [l];
	char *data2 = new char [l];
	is.read(data1, l);
	js.read(data2, l);
	is.close();
	os.close();
	char *key = new char [MAXKEYLEN];
	int keylen = 0;
	key = retrieve_key(data1, data2, l, keylen);
	unlock_file(key, keylen);
	return 0;
}
